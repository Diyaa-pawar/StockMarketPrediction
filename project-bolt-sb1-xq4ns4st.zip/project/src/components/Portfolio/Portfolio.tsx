import React, { useState, useEffect } from 'react';
import { TrendingUp, TrendingDown, Plus, Trash2 } from 'lucide-react';
import { stockService, POPULAR_STOCKS } from '../../services/stockAPI';

interface PortfolioItem {
  symbol: string;
  name: string;
  shares: number;
  purchasePrice: number;
  currentPrice: number;
}

export const Portfolio: React.FC = () => {
  const [portfolio, setPortfolio] = useState<PortfolioItem[]>([
    {
      symbol: 'AAPL',
      name: 'Apple Inc.',
      shares: 10,
      purchasePrice: 150.00,
      currentPrice: 175.25
    },
    {
      symbol: 'MSFT',
      name: 'Microsoft Corporation',
      shares: 5,
      purchasePrice: 300.00,
      currentPrice: 320.50
    }
  ]);

  const [newStock, setNewStock] = useState({
    symbol: 'AAPL',
    shares: '',
    purchasePrice: ''
  });

  const [showAddForm, setShowAddForm] = useState(false);

  useEffect(() => {
    // Update current prices periodically (simulated)
    const interval = setInterval(async () => {
      const updatedPortfolio = await Promise.all(
        portfolio.map(async (item) => {
          const currentPrice = await stockService.getCurrentPrice(item.symbol);
          return { ...item, currentPrice };
        })
      );
      setPortfolio(updatedPortfolio);
    }, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, [portfolio]);

  const addStock = async () => {
    if (!newStock.symbol || !newStock.shares || !newStock.purchasePrice) return;

    const stockInfo = POPULAR_STOCKS.find(s => s.symbol === newStock.symbol);
    const currentPrice = await stockService.getCurrentPrice(newStock.symbol);

    const newItem: PortfolioItem = {
      symbol: newStock.symbol,
      name: stockInfo?.name || newStock.symbol,
      shares: parseInt(newStock.shares),
      purchasePrice: parseFloat(newStock.purchasePrice),
      currentPrice
    };

    setPortfolio([...portfolio, newItem]);
    setNewStock({ symbol: 'AAPL', shares: '', purchasePrice: '' });
    setShowAddForm(false);
  };

  const removeStock = (index: number) => {
    setPortfolio(portfolio.filter((_, i) => i !== index));
  };

  const totalValue = portfolio.reduce((sum, item) => sum + (item.currentPrice * item.shares), 0);
  const totalCost = portfolio.reduce((sum, item) => sum + (item.purchasePrice * item.shares), 0);
  const totalGainLoss = totalValue - totalCost;
  const totalGainLossPercent = totalCost > 0 ? (totalGainLoss / totalCost) * 100 : 0;

  return (
    <div className="min-h-screen bg-slate-900 text-white p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold">Portfolio Management</h1>
          <button
            onClick={() => setShowAddForm(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition-colors flex items-center gap-2"
          >
            <Plus className="h-4 w-4" />
            Add Stock
          </button>
        </div>

        {/* Portfolio Summary */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <div className="bg-slate-800 rounded-lg p-6">
            <h3 className="text-lg font-medium text-slate-300 mb-2">Total Value</h3>
            <p className="text-2xl font-bold">₹{totalValue.toFixed(2)}</p>
          </div>
          <div className="bg-slate-800 rounded-lg p-6">
            <h3 className="text-lg font-medium text-slate-300 mb-2">Total Cost</h3>
            <p className="text-2xl font-bold">₹{totalCost.toFixed(2)}</p>
          </div>
          <div className="bg-slate-800 rounded-lg p-6">
            <h3 className="text-lg font-medium text-slate-300 mb-2">Gain/Loss</h3>
            <div className="flex items-center gap-2">
              {totalGainLoss >= 0 ? (
                <TrendingUp className="h-5 w-5 text-green-400" />
              ) : (
                <TrendingDown className="h-5 w-5 text-red-400" />
              )}
              <p className={`text-2xl font-bold ${totalGainLoss >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                ₹{totalGainLoss.toFixed(2)}
              </p>
            </div>
          </div>
          <div className="bg-slate-800 rounded-lg p-6">
            <h3 className="text-lg font-medium text-slate-300 mb-2">Return %</h3>
            <p className={`text-2xl font-bold ${totalGainLossPercent >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              {totalGainLossPercent.toFixed(2)}%
            </p>
          </div>
        </div>

        {/* Portfolio Holdings */}
        <div className="bg-slate-800 rounded-lg overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-700">
            <h2 className="text-xl font-semibold">Holdings</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-700">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-300 uppercase tracking-wider">Stock</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-300 uppercase tracking-wider">Shares</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-300 uppercase tracking-wider">Purchase Price</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-300 uppercase tracking-wider">Current Price</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-300 uppercase tracking-wider">Total Value</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-300 uppercase tracking-wider">Gain/Loss</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-300 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700">
                {portfolio.map((item, index) => {
                  const gainLoss = (item.currentPrice - item.purchasePrice) * item.shares;
                  const gainLossPercent = ((item.currentPrice - item.purchasePrice) / item.purchasePrice) * 100;

                  return (
                    <tr key={index} className="hover:bg-slate-700/50">
                      <td className="px-6 py-4">
                        <div>
                          <div className="text-sm font-medium text-white">{item.name}</div>
                          <div className="text-sm text-slate-400">{item.symbol}</div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-sm text-white">{item.shares}</td>
                      <td className="px-6 py-4 text-sm text-white">₹{item.purchasePrice.toFixed(2)}</td>
                      <td className="px-6 py-4 text-sm text-white">₹{item.currentPrice.toFixed(2)}</td>
                      <td className="px-6 py-4 text-sm text-white">₹{(item.currentPrice * item.shares).toFixed(2)}</td>
                      <td className="px-6 py-4 text-sm">
                        <div className={`${gainLoss >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          ₹{gainLoss.toFixed(2)}
                          <div className="text-xs">({gainLossPercent.toFixed(2)}%)</div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <button
                          onClick={() => removeStock(index)}
                          className="text-red-400 hover:text-red-300 transition-colors"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Add Stock Modal */}
        {showAddForm && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <div className="bg-slate-800 rounded-lg p-6 w-full max-w-md">
              <h3 className="text-lg font-semibold mb-4">Add New Stock</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Stock</label>
                  <select
                    value={newStock.symbol}
                    onChange={(e) => setNewStock({ ...newStock, symbol: e.target.value })}
                    className="w-full bg-slate-700 border border-slate-600 rounded-md px-3 py-2 text-white"
                  >
                    {POPULAR_STOCKS.map((stock) => (
                      <option key={stock.symbol} value={stock.symbol}>
                        {stock.name} ({stock.symbol})
                      </option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Shares</label>
                  <input
                    type="number"
                    value={newStock.shares}
                    onChange={(e) => setNewStock({ ...newStock, shares: e.target.value })}
                    className="w-full bg-slate-700 border border-slate-600 rounded-md px-3 py-2 text-white"
                    min="1"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Purchase Price</label>
                  <input
                    type="number"
                    step="0.01"
                    value={newStock.purchasePrice}
                    onChange={(e) => setNewStock({ ...newStock, purchasePrice: e.target.value })}
                    className="w-full bg-slate-700 border border-slate-600 rounded-md px-3 py-2 text-white"
                    min="0.01"
                  />
                </div>
              </div>
              
              <div className="flex gap-3 mt-6">
                <button
                  onClick={addStock}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition-colors"
                >
                  Add Stock
                </button>
                <button
                  onClick={() => setShowAddForm(false)}
                  className="flex-1 bg-slate-600 hover:bg-slate-700 text-white font-medium py-2 px-4 rounded-md transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};