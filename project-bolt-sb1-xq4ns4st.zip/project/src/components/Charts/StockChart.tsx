import React from 'react';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { StockData, ForecastData } from '../../types';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

interface StockChartProps {
  historicalData: StockData[];
  forecastData?: ForecastData[];
  title: string;
}

export const StockChart: React.FC<StockChartProps> = ({
  historicalData,
  forecastData = [],
  title
}) => {
  const labels = [...historicalData.map(d => d.date), ...forecastData.map(f => f.date)];
  
  const actualPrices = [
    ...historicalData.map(d => d.close),
    ...Array(forecastData.length).fill(null)
  ];
  
  const predictedPrices = [
    ...Array(historicalData.length - 50).fill(null),
    ...historicalData.slice(-50).map(d => d.close),
    ...forecastData.map(f => f.predicted)
  ];

  const data = {
    labels,
    datasets: [
      {
        label: 'Actual Price',
        data: actualPrices,
        borderColor: '#8B5CF6',
        backgroundColor: 'rgba(139, 92, 246, 0.1)',
        borderWidth: 2,
        pointRadius: 0,
        pointHoverRadius: 4,
      },
      {
        label: 'Predicted Price',
        data: predictedPrices,
        borderColor: '#F59E0B',
        backgroundColor: 'rgba(245, 158, 11, 0.1)',
        borderWidth: 2,
        pointRadius: 0,
        pointHoverRadius: 4,
        borderDash: forecastData.length > 0 ? [5, 5] : undefined,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          color: '#E2E8F0',
          font: {
            size: 12,
          },
        },
      },
      title: {
        display: true,
        text: title,
        color: '#E2E8F0',
        font: {
          size: 16,
          weight: 'bold',
        },
      },
    },
    scales: {
      x: {
        grid: {
          color: '#334155',
        },
        ticks: {
          color: '#94A3B8',
          maxTicksLimit: 8,
        },
      },
      y: {
        grid: {
          color: '#334155',
        },
        ticks: {
          color: '#94A3B8',
          callback: function(value: any) {
            return '₹' + value.toFixed(2);
          },
        },
      },
    },
  };

  return (
    <div className="bg-white rounded-lg p-4" style={{ height: '400px' }}>
      <Line data={data} options={options} />
    </div>
  );
};