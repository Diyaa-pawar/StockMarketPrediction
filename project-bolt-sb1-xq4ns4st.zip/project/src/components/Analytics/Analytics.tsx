import React, { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';
import { stockService, POPULAR_STOCKS } from '../../services/stockAPI';
import { Activity, TrendingUp, Target, BarChart3 } from 'lucide-react';

export const Analytics: React.FC = () => {
  const [selectedTimeframe, setSelectedTimeframe] = useState('1Y');
  const [comparisonData, setComparisonData] = useState<any[]>([]);
  const [sectorData, setSectorData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAnalyticsData();
  }, [selectedTimeframe]);

  const loadAnalyticsData = async () => {
    setLoading(true);
    
    // Generate comparison data for top stocks
    const topStocks = POPULAR_STOCKS.slice(0, 6);
    const comparison = await Promise.all(
      topStocks.map(async (stock) => {
        const currentPrice = await stockService.getCurrentPrice(stock.symbol);
        const yearAgoPrice = currentPrice * (0.8 + Math.random() * 0.4); // Simulate year-ago price
        const performance = ((currentPrice - yearAgoPrice) / yearAgoPrice) * 100;
        
        return {
          symbol: stock.symbol,
          name: stock.name,
          currentPrice,
          yearAgoPrice,
          performance: parseFloat(performance.toFixed(2)),
          volume: Math.floor(Math.random() * 10000000) + 1000000,
        };
      })
    );
    
    setComparisonData(comparison);
    
    // Generate sector distribution data
    const sectors = [
      { name: 'Technology', value: 35, color: '#3B82F6' },
      { name: 'Finance', value: 20, color: '#10B981' },
      { name: 'Healthcare', value: 15, color: '#F59E0B' },
      { name: 'Consumer', value: 12, color: '#EF4444' },
      { name: 'Energy', value: 10, color: '#8B5CF6' },
      { name: 'Others', value: 8, color: '#6B7280' },
    ];
    
    setSectorData(sectors);
    setLoading(false);
  };

  const topPerformers = comparisonData
    .sort((a, b) => b.performance - a.performance)
    .slice(0, 3);

  const marketMetrics = [
    {
      title: 'Market Cap',
      value: '₹45.2T',
      change: '+2.4%',
      icon: BarChart3,
      positive: true,
    },
    {
      title: 'Active Stocks',
      value: '2,847',
      change: '+12',
      icon: Activity,
      positive: true,
    },
    {
      title: 'Avg Performance',
      value: '+8.7%',
      change: '+1.2%',
      icon: TrendingUp,
      positive: true,
    },
    {
      title: 'Target Achieved',
      value: '73%',
      change: '+5%',
      icon: Target,
      positive: true,
    },
  ];

  return (
    <div className="min-h-screen bg-slate-900 text-white p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold">Market Analytics</h1>
          <div className="flex gap-2">
            {['1M', '3M', '6M', '1Y', '5Y'].map((timeframe) => (
              <button
                key={timeframe}
                onClick={() => setSelectedTimeframe(timeframe)}
                className={`px-4 py-2 rounded-md font-medium transition-colors ${
                  selectedTimeframe === timeframe
                    ? 'bg-blue-600 text-white'
                    : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                }`}
              >
                {timeframe}
              </button>
            ))}
          </div>
        </div>

        {/* Market Metrics */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          {marketMetrics.map((metric, index) => (
            <div key={index} className="bg-slate-800 rounded-lg p-6">
              <div className="flex items-center justify-between mb-2">
                <metric.icon className="h-8 w-8 text-blue-400" />
                <span className={`text-sm font-medium ${metric.positive ? 'text-green-400' : 'text-red-400'}`}>
                  {metric.change}
                </span>
              </div>
              <h3 className="text-lg font-medium text-slate-300 mb-1">{metric.title}</h3>
              <p className="text-2xl font-bold">{metric.value}</p>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Stock Performance Comparison */}
          <div className="bg-slate-800 rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-6">Stock Performance Comparison</h2>
            {loading ? (
              <div className="flex items-center justify-center h-64">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-400"></div>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={comparisonData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="symbol" stroke="#94A3B8" />
                  <YAxis stroke="#94A3B8" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1E293B', 
                      border: '1px solid #475569',
                      borderRadius: '6px',
                      color: '#E2E8F0'
                    }}
                  />
                  <Legend />
                  <Bar dataKey="performance" fill="#3B82F6" name="Performance %" />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>

          {/* Sector Distribution */}
          <div className="bg-slate-800 rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-6">Sector Distribution</h2>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={sectorData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {sectorData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1E293B', 
                    border: '1px solid #475569',
                    borderRadius: '6px',
                    color: '#E2E8F0'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Top Performers */}
        <div className="mt-8 bg-slate-800 rounded-lg p-6">
          <h2 className="text-xl font-semibold mb-6">Top Performers</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {topPerformers.map((stock, index) => (
              <div key={stock.symbol} className="bg-slate-700 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-lg font-medium">{stock.symbol}</span>
                  <span className="text-2xl font-bold">#{index + 1}</span>
                </div>
                <p className="text-sm text-slate-300 mb-2">{stock.name}</p>
                <div className="flex items-center justify-between">
                  <span className="text-lg font-bold">₹{stock.currentPrice.toFixed(2)}</span>
                  <span className={`font-bold ${stock.performance >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {stock.performance >= 0 ? '+' : ''}{stock.performance}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Detailed Analysis Table */}
        <div className="mt-8 bg-slate-800 rounded-lg overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-700">
            <h2 className="text-xl font-semibold">Detailed Stock Analysis</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-700">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-300 uppercase tracking-wider">Stock</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-300 uppercase tracking-wider">Current Price</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-300 uppercase tracking-wider">1Y Ago</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-300 uppercase tracking-wider">Performance</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-300 uppercase tracking-wider">Volume</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-slate-300 uppercase tracking-wider">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700">
                {comparisonData.map((stock, index) => (
                  <tr key={index} className="hover:bg-slate-700/50">
                    <td className="px-6 py-4">
                      <div>
                        <div className="text-sm font-medium text-white">{stock.name}</div>
                        <div className="text-sm text-slate-400">{stock.symbol}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-white font-medium">₹{stock.currentPrice.toFixed(2)}</td>
                    <td className="px-6 py-4 text-sm text-slate-300">₹{stock.yearAgoPrice.toFixed(2)}</td>
                    <td className="px-6 py-4 text-sm">
                      <span className={`font-bold ${stock.performance >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {stock.performance >= 0 ? '+' : ''}{stock.performance}%
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-300">{stock.volume.toLocaleString()}</td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        stock.performance >= 10 
                          ? 'bg-green-900 text-green-200'
                          : stock.performance >= 0
                          ? 'bg-blue-900 text-blue-200'
                          : 'bg-red-900 text-red-200'
                      }`}>
                        {stock.performance >= 10 ? 'Excellent' : stock.performance >= 0 ? 'Good' : 'Underperform'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};