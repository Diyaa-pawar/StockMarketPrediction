import React, { useState, useEffect } from 'react';
import { ChevronDown, Play, Loader2 } from 'lucide-react';
import { stockService, POPULAR_STOCKS } from '../../services/stockAPI';
import { StockChart } from '../Charts/StockChart';
import { StockData } from '../../types';
import { authService } from '../../services/authService';

export const Dashboard: React.FC = () => {
  const [selectedStock, setSelectedStock] = useState('AAPL');
  const [historicalData, setHistoricalData] = useState<StockData[]>([]);
  const [predictions, setPredictions] = useState<number[]>([]);
  const [metrics, setMetrics] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const currentUser = authService.getCurrentUser();

  useEffect(() => {
    loadStockData();
  }, [selectedStock]);

  const loadStockData = async () => {
    setLoading(true);
    try {
      const data = await stockService.getHistoricalData(selectedStock);
      setHistoricalData(data);
      
      // Auto-generate predictions
      const result = stockService.generatePredictions(data, 3);
      setPredictions(result.predictions);
      setMetrics(result.metrics);
    } catch (error) {
      console.error('Error loading stock data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRunForecast = async () => {
    if (historicalData.length === 0) return;
    
    setLoading(true);
    
    // Simulate forecast calculation delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const result = stockService.generatePredictions(historicalData, 3);
    setPredictions(result.predictions);
    setMetrics(result.metrics);
    setLoading(false);
  };

  const selectedStockInfo = POPULAR_STOCKS.find(s => s.symbol === selectedStock);

  const forecastDates = [
    new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
  ];

  return (
    <div className="min-h-screen bg-slate-900 text-white p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold mb-2">Stock Forecasting Application</h1>
        <p className="text-xl text-slate-300 mb-8">
          Hello, {currentUser?.username || 'User'}!
        </p>
        
        <p className="text-slate-300 mb-6">
          Select a stock from the dropdown below to run the forecast:
        </p>

        <div className="bg-slate-800 rounded-lg p-6 mb-6">
          <div className="mb-4">
            <label className="block text-sm font-medium text-slate-300 mb-2">
              Select Stock
            </label>
            <div className="relative">
              <button
                onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                className="w-full max-w-md bg-slate-700 border border-slate-600 rounded-md px-4 py-2 text-left flex items-center justify-between hover:bg-slate-600 transition-colors"
              >
                <span>{selectedStockInfo?.name || selectedStock}</span>
                <ChevronDown className="h-4 w-4" />
              </button>
              
              {isDropdownOpen && (
                <div className="absolute top-full left-0 w-full max-w-md mt-1 bg-slate-700 border border-slate-600 rounded-md shadow-lg z-50 max-h-60 overflow-y-auto">
                  {POPULAR_STOCKS.map((stock) => (
                    <button
                      key={stock.symbol}
                      onClick={() => {
                        setSelectedStock(stock.symbol);
                        setIsDropdownOpen(false);
                      }}
                      className="w-full text-left px-4 py-2 hover:bg-slate-600 transition-colors"
                    >
                      <div>
                        <div className="font-medium">{stock.name}</div>
                        <div className="text-sm text-slate-400">{stock.symbol} • {stock.exchange}</div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          <button
            onClick={handleRunForecast}
            disabled={loading || historicalData.length === 0}
            className="bg-red-600 hover:bg-red-700 text-white font-medium py-2 px-6 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Fetching data and running forecast...
              </>
            ) : (
              <>
                <Play className="h-4 w-4" />
                Run Forecast
              </>
            )}
          </button>
        </div>

        {historicalData.length > 0 && (
          <div className="grid lg:grid-cols-2 gap-6">
            <div>
              <StockChart
                historicalData={historicalData}
                title={`${selectedStockInfo?.name || selectedStock} - Actual vs Predicted (In-sample, Last 20 Years)`}
              />
              
              {metrics && (
                <div className="mt-4 text-lg">
                  <span className="text-slate-300">Random Forest R² Score: </span>
                  <span className="font-bold">{metrics.r2Score}</span>
                </div>
              )}
            </div>

            <div className="space-y-6">
              {predictions.length > 0 && (
                <div className="bg-slate-800 rounded-lg p-6">
                  <h3 className="text-xl font-bold mb-4">Next 3 Days Forecast</h3>
                  <div className="space-y-3">
                    {predictions.map((price, index) => (
                      <div key={index} className="text-lg">
                        <span className="text-slate-300">{forecastDates[index]}: </span>
                        <span className="font-bold">₹{price.toFixed(2)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {metrics && (
                <div className="bg-slate-800 rounded-lg p-6">
                  <h3 className="text-xl font-bold mb-4">Model Performance</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-slate-300">R² Score:</span>
                      <span className="font-bold">{metrics.r2Score}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-300">RMSE:</span>
                      <span className="font-bold">{metrics.rmse}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-300">MAE:</span>
                      <span className="font-bold">{metrics.mae}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-300">Accuracy:</span>
                      <span className="font-bold text-green-400">{metrics.accuracy}%</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};