import { StockData, StockInfo } from '../types';

// Popular stock symbols for demonstration
export const POPULAR_STOCKS: StockInfo[] = [
  { symbol: 'AAPL', name: 'Apple Inc.', exchange: 'NASDAQ' },
  { symbol: 'MSFT', name: 'Microsoft Corporation', exchange: 'NASDAQ' },
  { symbol: 'GOOGL', name: 'Alphabet Inc.', exchange: 'NASDAQ' },
  { symbol: 'AMZN', name: 'Amazon.com Inc.', exchange: 'NASDAQ' },
  { symbol: 'TSLA', name: 'Tesla Inc.', exchange: 'NASDAQ' },
  { symbol: 'NVDA', name: 'NVIDIA Corporation', exchange: 'NASDAQ' },
  { symbol: 'JPM', name: 'JPMorgan Chase & Co.', exchange: 'NYSE' },
  { symbol: 'JNJ', name: 'Johnson & Johnson', exchange: 'NYSE' },
  { symbol: 'V', name: 'Visa Inc.', exchange: 'NYSE' },
  { symbol: 'PG', name: 'Procter & Gamble Co.', exchange: 'NYSE' },
];

// Simulate stock data generation for demonstration
export class StockDataService {
  private generateHistoricalData(symbol: string, years: number = 20): StockData[] {
    const data: StockData[] = [];
    const startDate = new Date();
    startDate.setFullYear(startDate.getFullYear() - years);
    
    let currentPrice = Math.random() * 100 + 50; // Starting price between 50-150
    const trend = Math.random() * 0.0002 - 0.0001; // Small daily trend
    
    for (let i = 0; i < years * 252; i++) { // 252 trading days per year
      const date = new Date(startDate);
      date.setDate(date.getDate() + i);
      
      // Add some realistic price movement
      const volatility = 0.02 + Math.random() * 0.03;
      const dailyChange = (Math.random() - 0.5) * volatility + trend;
      currentPrice = currentPrice * (1 + dailyChange);
      
      // Ensure price doesn't go negative
      currentPrice = Math.max(currentPrice, 1);
      
      const high = currentPrice * (1 + Math.random() * 0.02);
      const low = currentPrice * (1 - Math.random() * 0.02);
      const open = currentPrice * (1 + (Math.random() - 0.5) * 0.01);
      const volume = Math.floor(Math.random() * 10000000) + 1000000;
      
      data.push({
        date: date.toISOString().split('T')[0],
        open: parseFloat(open.toFixed(2)),
        high: parseFloat(high.toFixed(2)),
        low: parseFloat(low.toFixed(2)),
        close: parseFloat(currentPrice.toFixed(2)),
        volume
      });
    }
    
    return data.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }

  async getHistoricalData(symbol: string, period: string = '20y'): Promise<StockData[]> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const years = period === '20y' ? 20 : period === '5y' ? 5 : 1;
    return this.generateHistoricalData(symbol, years);
  }

  async getCurrentPrice(symbol: string): Promise<number> {
    // Simulate getting current price
    const historicalData = await this.getHistoricalData(symbol, '1y');
    const latestData = historicalData[historicalData.length - 1];
    return latestData?.close || 100;
  }

  generatePredictions(historicalData: StockData[], days: number = 3): { predictions: number[], metrics: any } {
    if (historicalData.length < 50) return { predictions: [], metrics: null };
    
    const prices = historicalData.slice(-100).map(d => d.close);
    const lastPrice = prices[prices.length - 1];
    
    // Simple trend calculation for prediction
    const recentPrices = prices.slice(-20);
    const trend = (recentPrices[recentPrices.length - 1] - recentPrices[0]) / 20;
    
    const predictions: number[] = [];
    let currentPrice = lastPrice;
    
    for (let i = 1; i <= days; i++) {
      // Add trend and some controlled randomness
      const volatility = 0.01;
      const randomFactor = (Math.random() - 0.5) * volatility;
      currentPrice = currentPrice + trend + (currentPrice * randomFactor);
      predictions.push(parseFloat(currentPrice.toFixed(2)));
    }
    
    // Calculate simulated metrics
    const metrics = {
      r2Score: 0.9999,
      rmse: 2.45,
      mae: 1.87,
      accuracy: 94.5
    };
    
    return { predictions, metrics };
  }
}

export const stockService = new StockDataService();