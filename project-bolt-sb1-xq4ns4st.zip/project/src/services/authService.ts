import { User } from '../types';

class AuthService {
  private users: User[] = [];
  private currentUser: User | null = null;

  async login(username: string, password: string): Promise<User> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // For demo, accept any non-empty credentials
    if (!username || !password) {
      throw new Error('Username and password are required');
    }
    
    // Check if user exists in our registered users
    const user = this.users.find(u => u.username === username);
    
    if (!user) {
      throw new Error('User not found. Please sign up first.');
    }
    
    // In a real app, you would verify the password hash here
    // For demo purposes, we'll accept any password for existing users
    
    this.currentUser = user;
    localStorage.setItem('currentUser', JSON.stringify(user));
    return user;
  }

  async signup(username: string, email: string, password: string): Promise<User> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    if (!username || !email || !password) {
      throw new Error('All fields are required');
    }
    
    // Check if username already exists
    const existingUser = this.users.find(u => u.username === username || u.email === email);
    if (existingUser) {
      throw new Error('Username or email already exists');
    }
    
    const user: User = {
      id: Date.now().toString(),
      username,
      email
    };
    
    this.users.push(user);
    this.currentUser = user;
    
    // Store users in localStorage for persistence across sessions
    localStorage.setItem('registeredUsers', JSON.stringify(this.users));
    localStorage.setItem('currentUser', JSON.stringify(user));
    return user;
  }

  logout(): void {
    this.currentUser = null;
    localStorage.removeItem('currentUser');
  }

  constructor() {
    // Load registered users from localStorage on initialization
    const storedUsers = localStorage.getItem('registeredUsers');
    if (storedUsers) {
      this.users = JSON.parse(storedUsers);
    }
  }

  getCurrentUser(): User | null {
    if (this.currentUser) return this.currentUser;
    
    const stored = localStorage.getItem('currentUser');
    if (stored) {
      this.currentUser = JSON.parse(stored);
      return this.currentUser;
    }
    
    return null;
  }

  isAuthenticated(): boolean {
    return this.getCurrentUser() !== null;
  }

  // Method to check if a username exists (useful for validation)
  userExists(username: string): boolean {
    return this.users.some(u => u.username === username);
  }

  // Method to get all registered users (for admin purposes)
  getAllUsers(): User[] {
    return this.users;
  }
}

export const authService = new AuthService();