export interface User {
  id: string;
  username: string;
  email: string;
}

export interface StockData {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface ForecastData {
  date: string;
  predicted: number;
  actual?: number;
}

export interface StockInfo {
  symbol: string;
  name: string;
  exchange: string;
}

export interface PredictionMetrics {
  r2Score: number;
  rmse: number;
  mae: number;
  accuracy: number;
}

export interface TechnicalIndicators {
  sma20: number;
  sma50: number;
  ema12: number;
  ema26: number;
  rsi: number;
  macd: number;
  bollinger: {
    upper: number;
    middle: number;
    lower: number;
  };
}